<?php 
// Actualizamos en funcion del id que recibimos 
include ("../modelo/interfazConect.php");
include ('fpdf/fpdf.php');
$pdf = new FPDF();
        $pdf->AddPage();
        
        $pdf->SetFont('Helvetica', 'B', 14);
		$pdf->Write (1,"DATOS DE VOTANTE ","");
		$pdf->Ln();
                $pdf->Ln();
                $pdf->Ln();
                $pdf->Write (7,"ID VOTANTE "," "," ");
		$pdf->Write (7, $_POST['num_documento']);
		$pdf->Ln(); //salto de linea
                $pdf->Ln(); //salto de linea
                
		$pdf->Cell(60,7,$_POST['tipo_doc'],1,0,'C');
		$pdf->Ln(15);//ahora salta 15
                
		$pdf->SetTextColor('255','0','0');//para imprimir en rojo 
          $pdf->Write (7,"Fecha de creacion VOTANTE ","");
                          $pdf->Ln();
          $pdf->Multicell(190,7,$_POST['fecha']."\n ",1,'R');
                
                $pdf->SetTextColor('255','0','0');//para imprimir en rojo 
          $pdf->Write (7,"Genero","");
                          $pdf->Ln();
          $pdf->Multicell(190,7,$_POST['genero']."\n ",1,'R');
                
           /////////////////////////////////////////////////////     
           $pdf->SetTextColor('255','0','0');//para imprimir en rojo 
          $pdf->Write (7,"Primer nombre","");
                          $pdf->Ln();
          $pdf->Multicell(190,7,$_POST['primer_nombre']."\n ",1,'R');
		$pdf->Line(0,160,300,160);//impresión de linea     
        //////////////////////////////////////////////////////////// 
                
                /////////////////////////////////////////////////////     
           $pdf->SetTextColor('255','0','0');//para imprimir en rojo 
          $pdf->Write (7,"Segundo nombre","");
                          $pdf->Ln();
          $pdf->Multicell(190,7,$_POST['segundo_nombre']."\n ",1,'R');
		 
        ////////////////////////////////////////////////////////////   
                
                ///////////////////////////////////////////////////// 
                 
           $pdf->SetTextColor('255','0','0');//para imprimir en rojo 
          $pdf->Write (7,"Primer apellido","");
                          $pdf->Ln();
          $pdf->Multicell(190,7,$_POST['primer_apellido']."\n ",1,'R');
		  
        ////////////////////////////////////////////////////////////   
                
                /////////////////////////////////////////////////////     
           $pdf->SetTextColor('255','0','0');//para imprimir en rojo 
          $pdf->Write (7,"Segundo apellido","");
                          $pdf->Ln();
          $pdf->Multicell(190,7,$_POST['segundo_apellido']."\n ",1,'R');
        //////////////////////////////////////////////////////////// 
          
          
          
          
          
           /////////////////////////////////////////////////////     
           $pdf->SetTextColor('255','0','0');//para imprimir en rojo 
          $pdf->Write (7,"Fecha de nacimiento","");
                          $pdf->Ln();
          $pdf->Multicell(190,7,$_POST['fch_nacimiento']."\n ",1,'R');
        ////////////////////////////////////////////////////////////  
           /////////////////////////////////////////////////////     
           $pdf->SetTextColor('255','0','0');//para imprimir en rojo 
          $pdf->Write (7,"Edad","");
                          $pdf->Ln();
          $pdf->Multicell(190,7,$_POST['edad']."\n ",1,'R');
        ////////////////////////////////////////////////////////////  
           /////////////////////////////////////////////////////     
           $pdf->SetTextColor('255','0','0');//para imprimir en rojo 
          $pdf->Write (7,"Lugar de nacimiento","");
                          $pdf->Ln();
          $pdf->Multicell(190,7,$_POST['lugar_nacimiento']."\n ",1,'R');
        ////////////////////////////////////////////////////////////  
           /////////////////////////////////////////////////////     
           $pdf->SetTextColor('255','0','0');//para imprimir en rojo 
          $pdf->Write (7,"Estado civil","");
                          $pdf->Ln();
          $pdf->Multicell(190,7,$_POST['estado_civil']."\n ",1,'R');
        ////////////////////////////////////////////////////////////  
           /////////////////////////////////////////////////////     
           $pdf->SetTextColor('255','0','0');//para imprimir en rojo 
          $pdf->Write (7,"Direccion de domicilio","");
                          $pdf->Ln();
          $pdf->Multicell(190,7,$_POST['direccion_domicilio']."\n ",1,'R');
        ////////////////////////////////////////////////////////////  
           /////////////////////////////////////////////////////     
           $pdf->SetTextColor('255','0','0');//para imprimir en rojo 
          $pdf->Write (7,"Barrio donde vive","");
                          $pdf->Ln();
          $pdf->Multicell(190,7,$_POST['barrio']."\n ",1,'R');
        ////////////////////////////////////////////////////////////  
           /////////////////////////////////////////////////////     
           $pdf->SetTextColor('255','0','0');//para imprimir en rojo 
          $pdf->Write (7,"Telefono de domicilio","");
                          $pdf->Ln();
          $pdf->Multicell(190,7,$_POST['tel_domicilio']."\n ",1,'R');
        ////////////////////////////////////////////////////////////  
           /////////////////////////////////////////////////////     
           $pdf->SetTextColor('255','0','0');//para imprimir en rojo 
          $pdf->Write (7,"Numero celular","");
                          $pdf->Ln();
          $pdf->Multicell(190,7,$_POST['cel_domicilio']."\n ",1,'R');
        ////////////////////////////////////////////////////////////  
           /////////////////////////////////////////////////////     
           $pdf->SetTextColor('255','0','0');//para imprimir en rojo 
          $pdf->Write (7,"EPS","");
                          $pdf->Ln();
          $pdf->Multicell(190,7,$_POST['eps']."\n ",1,'R');
        ////////////////////////////////////////////////////////////  
           /////////////////////////////////////////////////////     
          
        ////////////////////////////////////////////////////////////  
           ////////////////////////////////////////////////////////////  
           /////////////////////////////////////////////////////     
           $pdf->SetTextColor('255','0','0');//para imprimir en rojo 
          $pdf->Write (7,"Evaluador de datos personales ","");
                          $pdf->Ln();
          $pdf->Multicell(190,7,$_POST['evaluador']."\n ",1,'R');
        ////////////////////////////////////////////////////////////  
           ////////////////////////////////////////////////////////////  
           /////////////////////////////////////////////////////  
                                    $pdf->Ln();
                          $pdf->Ln();
                          $pdf->Ln();
                          $pdf->Ln();
                          
  


 
                     
        $pdf->Output("Historia Clinica salud ocupacional.pdf",'F');
		echo "<script language='javascript'>window.open('Historia Clinica salud ocupacional.pdf','_self','');</script>";//para ver el archivo pdf generado
		exit;
                
                
                
                
                
                
                
                
                
        
        



$documento = $_POST['num_documento'];


$tipo_doc = $_POST['tipo_doc']; 
$fecha = $_POST['fecha']; 


$genero = $_POST['genero']; 
$primer_nombre = $_POST['primer_nombre'];
$segundo_nombre = $_POST['segundo_nombre'];
$primer_apellido = $_POST['primer_apellido'];
$segundo_apellido = $_POST['segundo_apellido'];

$fch_nacimiento = $_POST['fch_nacimiento'];
$edad = $_POST['edad'];
$lugar_nacimiento = $_POST['lugar_nacimiento'];
$estado_civil = $_POST['estado_civil'];
$direccion_domicilio = $_POST['direccion_domicilio'];
$barrio = $_POST['barrio'];
$tel_domicilio = $_POST['tel_domicilio'];
$cel_domicilio = $_POST['cel_domicilio'];
$eps = $_POST['eps'];

$evaluador = $_POST['evaluador'];




   


 
            $interConexion = new interConexion(); 
$interConexion->editar_pdf($documento, $tipo_doc, $fecha, $genero, $primer_nombre, $segundo_nombre, $primer_apellido, $segundo_apellido,
        $fch_nacimiento, $edad, $lugar_nacimiento, $estado_civil, $direccion_domicilio, $barrio, $tel_domicilio, $cel_domicilio, $eps, $evaluador
        );    
?>

 

