<?php
include ("../modelo/interfazConect.php");
$documento = $_POST['documento'];
$tipo_doc = $_POST['tipo_doc']; 

$fecha = $_POST['fecha']; 

$gen = $_POST['gen']; 
$prinom = $_POST['nom'];
$segnom = $_POST['segg'];
$priape = $_POST['apelld'];
$segape = $_POST['segunapelld'];
$naci = $_POST['fecha1'];

$lugnaci = $_POST['lugna'];
$esta = $_POST['estad'];
$didom = $_POST['dirdo'];
$ba = $_POST['bar'];
$tedom = $_POST['teldom'];




$eva = $_POST['evalu'];
$nivel_academico_actual = $_POST['nivel_academico_actual'];



$interConexion = new interConexion(); 
$interConexion->registro_usuario($documento, $tipo_doc, $fecha, $gen, $prinom, $segnom, $priape, $segape,
        $naci, $lugnaci, $esta, $didom, $ba, $tedom,  $eva, $nivel_academico_actual);
?>




