
<?php
session_start();
if(isset ($_SESSION['id'])) {
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Modificar y Completar informacion</title>
       <!-- <link rel="stylesheet" type ="text/css" href="css/wish_list.css">
        <link rel="stylesheet" type ="text/css" href="css/tabla.css">
       -->
    </head>
    <body>
    <center>
        <a href ="..vistas/menu.php" class = "">Volver...</a>    
        
    <div class ="">   
        
        
            
        
          
            
            <h3 class = "">Usuario ...</h3>
           
             <table id="">
           
                <tr>
                </tr>


<?php
include ("../modelo/interfazConect.php");
$documento = $_POST['documento'];
$pre = $_POST['pre'];



$interConexion = new interConexion(); 
$interConexion->certificado_ocupacional_pdf_2($documento, $pre);

?>
                
                
                
 </table>
         
            
            
   

      
           
    </div>  
    </center>
    </body>
</html>
<?php
}else{echo "Debes iniciar sesion antes de acceder a esta pagina"; } ?>