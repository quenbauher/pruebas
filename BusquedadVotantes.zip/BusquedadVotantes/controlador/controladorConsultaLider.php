<?php
session_start();
if(isset ($_SESSION['id'])) {
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Modificar y Completar informacion</title>
        <link rel="stylesheet" type ="text/css" href="css/wish_list.css">
        <link rel="stylesheet" type ="text/css" href="css/tabla.css">
    </head>
    <body>
    <center>
        <a href ="../vistas/vistaConsultaLider.php" class = "">Volver...</a>    
        
    <div class ="">   
        
        
            
        
          
            
            <h3 class = "title">Usuario ...</h3>
           
             <table id="tabla">
           
                <tr>
                </tr>


<?php
include ("../modelo/interfazConect.php");
$evaluador = $_POST['evaluador'];
$nivel_academico_actual = $_POST['nivel_academico_actual'];
$pre = $_POST['pre'];



$interConexion = new interConexion(); 
$interConexion->modeloConsultaLider($evaluador, $nivel_academico_actual, $pre);//aqui me toca crear la funcion dentro de la clase interconexion

?>
                
                
                
 </table>
         
            
            
   

      
           
    </div>  
    </center>
    </body>
</html>
<?php
}else{echo "Debes iniciar sesion antes de acceder a esta pagina"; } ?>