<?php 
// Actualizamos en funcion del id que recibimos 
include ("../modelo/interfazConect.php");

$evaluadorChek = $_POST['evaluador'];
$wisher_id = $_POST['wisher_id']; 
$primer_nombre = $_POST['primer_nombre']; 
$genero = $_POST['genero']; 

            $interConexion = new interConexion(); 
$interConexion->modeloEditarLider($evaluadorChek, $wisher_id, $primer_nombre, $genero);    
?>

 

