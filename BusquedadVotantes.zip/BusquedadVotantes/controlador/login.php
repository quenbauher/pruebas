<?php

include ("../modelo/interfazConect.php");

$usuario = $_POST['usuario'];
$pass = $_POST['pass'];  

//interconexion es una isntancia de la clase
//la cual luego de instanciar de su clase la llamamos
//ahora se aloja en la variable $interconexio
//la cual le pasa una funcion de nombre login que 
//maneja dos parametros user y pas que son los que envia 
//a la clase interconexion utilizando su funcion 
//login
$interConexion = new interConexion(); 
$interConexion -> login($usuario , $pass); 
 


?>