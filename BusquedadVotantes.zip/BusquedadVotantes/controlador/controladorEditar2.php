<?php 
// Actualizamos en funcion del id que recibimos 
include ("../modelo/interfazConect.php");

$evaluador = $_POST['evaluador'];
$nivel_academico_actual = $_POST['nivel_academico_actual'];

$wisher_id = $_POST['wisher_id']; 
$primer_nombre = $_POST['primer_nombre']; 
$segundo_nombre = $_POST['segundo_nombre']; 
$primer_apellido = $_POST['primer_apellido']; 

$segundo_apellido = $_POST['segundo_apellido']; 
$fch_nacimiento= $_POST['fch_nacimiento']; 
$lugar_nacimiento = $_POST['lugar_nacimiento']; 
$estado_civil = $_POST['estado_civil']; 
$direccion_domicilio = $_POST['direccion_domicilio']; 
$barrio = $_POST['barrio']; 
$tel_domicilio = $_POST['tel_domicilio']; 



            $interConexion = new interConexion(); 
$interConexion->modeloEditarLider2($evaluador,$nivel_academico_actual,$wisher_id, $primer_nombre,
        $segundo_nombre,$primer_apellido,$segundo_apellido,$fch_nacimiento,$lugar_nacimiento,
        $estado_civil,$direccion_domicilio,$barrio,$tel_domicilio);    
?>

 
