

<?php 
// Actualizamos en funcion del id que recibimos 
include ("../modelo/interfazConect.php");

$documento = $_POST['num_documento'];


$tipo_doc = $_POST['tipo_doc']; 
$fecha = $_POST['fecha']; 


$genero = $_POST['genero']; 
$primer_nombre = $_POST['primer_nombre'];
$segundo_nombre = $_POST['segundo_nombre'];
$primer_apellido = $_POST['primer_apellido'];
$segundo_apellido = $_POST['segundo_apellido'];
$fch_nacimiento = $_POST['fch_nacimiento'];
$edad = $_POST['edad'];
$lugar_nacimiento = $_POST['lugar_nacimiento'];
$estado_civil = $_POST['estado_civil'];
$direccion_domicilio = $_POST['direccion_domicilio'];
$barrio = $_POST['barrio'];
$tel_domicilio = $_POST['tel_domicilio'];
$cel_domicilio = $_POST['cel_domicilio'];
$eps = $_POST['eps'];

$evaluador = $_POST['evaluador'];

 
 
 
 
            $interConexion = new interConexion(); 
$interConexion->editar_Eliminar($documento, $tipo_doc, $fecha, $genero, $primer_nombre, $segundo_nombre, $primer_apellido, $segundo_apellido,
        $fch_nacimiento, $edad, $lugar_nacimiento, $estado_civil, $direccion_domicilio, $barrio, $tel_domicilio, $cel_domicilio, $eps,  $evaluador);    
?>

 

