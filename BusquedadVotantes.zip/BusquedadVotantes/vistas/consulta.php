<?php
session_start();
if(isset ($_SESSION['id'])) {
?>
<HTML>
<HEAD>
<TITLE>INICIO</TITLE>
<meta charset = "UTF-8"> 
<LINK REL = "stylesheet" type = "text/css" href = "css/menu.css" > 
<LINK REL = "stylesheet" type = "text/css" href = "css/add_wish.css" >
</HEAD>
<body>        <a href ="menu.php" class = "uno">Volver a menu...</a>       
    <p id ="title">Escoge una opcion
    <?php
    echo $_SESSION['name'] ;
    echo " " ;
    echo $_SESSION['apellido'];
    ?>
    </p>
<header>
    
  <div class = "contenedor-fluid" id = "dos">    
    
    
    
    
		<div class = "contenedor" id = "dos"> 
                    
			<a href = "consultaMed_laboral.php">
                            <p class = "parrafo">Consulta y actualiza votantes</p>
                            <img class = "icon2"  src = "imagen/enfermera-medico.gif" >
			
		</a>
		</div>
   
              
    
      <BR>
    <BR>
    <BR>
		
      
      
      <div class = "contenedor" id = "tres"> 
               
          <a href = "consultaMed_laboral_Copia.php">
               <p class = "parrafo">Elimine Votantes</p>    
                            <img class = "icon2" src="imagen/deportista.gif">
			
			</a>
                    
		</div>
      
      
      
    </div>
    <br><BR>
     <br><BR>
      <br><BR>
</header>
   <br><BR>
      <br><BR>
      <br><BR>
     <br><BR>
      <br><BR>                                          
</body>
 
</HTML>
<?php
}else{echo "Debes iniciar sesion antes de acceder a esta pagina"; } ?>
