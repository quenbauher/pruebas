<?php
session_start();
if(isset ($_SESSION['id'])) {
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Generador Archivos PDF</title>
        <link rel="stylesheet" type ="text/css" href="css/consulta.css">
    </head>
    <body>
    <center>
        <a href ="menu.php" class = "uno">Volver a menu...</a>       
    <div class ="maik">   
        
        <form class="ocho_3"method ="POST" action="../controlador/certificado_ocupacional.php">
            <h3 class = "title">Buscar Votante</h3>
            
            
            
            <p>Numero de documento</p><input title = "se necesita llenar" size="15"type = "text" name = "documento" placeholder = "Numero documento" required> 

            
             
 <!--               <table><input type="reset" value="Limpiar" class ="uno"> <input type="submit" value="Agregar usuario" class="uno">
                             <input TYPE="SUBMIT" NAME="buscar" VALUE="Buscar" class="dos">
                   <input action ="../controlador/consulta_usuario.php" method ="POST" TYPE="SUBMIT" NAME="buscar" VALUE="Buscar" ID="P" class="dos"/>
   -->
                   
                  
   <input class="dos"type="submit" name="pre" />
                   <input type="reset" value="Limpiar" class ="uno">
</form>       

               
          
    </div>                               

         <div class ="maik">   
        
        <form class="ocho_3"method ="POST" action="../controlador/certificado_ocupacional_2.php">
            <h3 class = "title"> Buscar Lider de Votación y 15 amigos</h3>
            
            
            
            <p>Numero de documento</p><input title = "se necesita llenar" size="15"type = "text" name = "documento" placeholder = "Numero documento" required> 

            
             
 <!--               <table><input type="reset" value="Limpiar" class ="uno"> <input type="submit" value="Agregar usuario" class="uno">
                             <input TYPE="SUBMIT" NAME="buscar" VALUE="Buscar" class="dos">
                   <input action ="../controlador/consulta_usuario.php" method ="POST" TYPE="SUBMIT" NAME="buscar" VALUE="Buscar" ID="P" class="dos"/>
   -->
                   
                  
   <input class="dos"type="submit" name="pre" />
                   <input type="reset" value="Limpiar" class ="uno">
</form>       

               
          
    </div> 
        
        
        
        
        
        
        
        
        
    </center>
    </body>
</html>
<?php
}else{
    echo"Debes iniciar sesion antes de acceder a esta pagina"; 
}
?>