-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 24-01-2019 a las 05:03:26
-- Versión del servidor: 5.6.21
-- Versión de PHP: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `aml_2`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `registro_administrador`
--

CREATE TABLE IF NOT EXISTS `registro_administrador` (
`id` int(15) NOT NULL,
  `nombre` varchar(45) CHARACTER SET latin1 NOT NULL,
  `apellido` varchar(45) CHARACTER SET latin1 NOT NULL,
  `usuario` varchar(45) CHARACTER SET latin1 NOT NULL,
  `password` varchar(45) CHARACTER SET latin1 NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- Volcado de datos para la tabla `registro_administrador`
--

INSERT INTO `registro_administrador` (`id`, `nombre`, `apellido`, `usuario`, `password`) VALUES
(10, 'Usuario', 'Administrador Sede', 'bekem', '123'),
(11, 'ddd', 'rrr', 'a', '1'),
(12, 'e', 'r', 'f', 'f'),
(13, 'eeeeee', 'eeeeeeeeeeeee', 'e', 'e'),
(14, 'we', 'we', 'we', '8');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `registro_usuario`
--

CREATE TABLE IF NOT EXISTS `registro_usuario` (
`id` int(15) NOT NULL,
  `num_documento` varchar(45) COLLATE utf8mb4_spanish_ci NOT NULL,
  `tipo_doc` varchar(250) COLLATE utf8mb4_spanish_ci NOT NULL,
  `fecha` datetime NOT NULL,
  `genero` varchar(45) COLLATE utf8mb4_spanish_ci NOT NULL,
  `primer_nombre` varchar(45) COLLATE utf8mb4_spanish_ci NOT NULL,
  `segundo_nombre` varchar(45) COLLATE utf8mb4_spanish_ci NOT NULL,
  `primer_apellido` varchar(45) COLLATE utf8mb4_spanish_ci NOT NULL,
  `segundo_apellido` varchar(45) COLLATE utf8mb4_spanish_ci NOT NULL,
  `fch_nacimiento` date NOT NULL,
  `edad` varchar(5) COLLATE utf8mb4_spanish_ci NOT NULL,
  `lugar_nacimiento` varchar(45) COLLATE utf8mb4_spanish_ci NOT NULL,
  `estado_civil` varchar(45) COLLATE utf8mb4_spanish_ci NOT NULL,
  `direccion_domicilio` varchar(45) COLLATE utf8mb4_spanish_ci NOT NULL,
  `barrio` varchar(45) COLLATE utf8mb4_spanish_ci NOT NULL,
  `tel_domicilio` varchar(45) COLLATE utf8mb4_spanish_ci NOT NULL,
  `cel_domicilio` varchar(45) COLLATE utf8mb4_spanish_ci NOT NULL,
  `eps` varchar(55) COLLATE utf8mb4_spanish_ci NOT NULL,
  `arl` varchar(45) COLLATE utf8mb4_spanish_ci NOT NULL,
  `fondo_pensiones` varchar(45) COLLATE utf8mb4_spanish_ci NOT NULL,
  `caja_compensacion` varchar(45) COLLATE utf8mb4_spanish_ci NOT NULL,
  `nom_cntcto_fmliar` varchar(45) COLLATE utf8mb4_spanish_ci NOT NULL,
  `parentesco` varchar(45) COLLATE utf8mb4_spanish_ci NOT NULL,
  `tel_fmliar` varchar(45) COLLATE utf8mb4_spanish_ci NOT NULL,
  `cel_fmliar` varchar(45) COLLATE utf8mb4_spanish_ci NOT NULL,
  `nombre_empresa` varchar(45) COLLATE utf8mb4_spanish_ci NOT NULL,
  `telefono` varchar(45) COLLATE utf8mb4_spanish_ci NOT NULL,
  `oficio_habitual` varchar(54) COLLATE utf8mb4_spanish_ci NOT NULL,
  `deporte_practicar` varchar(54) COLLATE utf8mb4_spanish_ci NOT NULL,
  `evaluador` varchar(45) COLLATE utf8mb4_spanish_ci NOT NULL,
  `nivel_academico_actual` int(25) NOT NULL,
  `estudiando` varchar(5) COLLATE utf8mb4_spanish_ci NOT NULL,
  `profesion` varchar(45) COLLATE utf8mb4_spanish_ci NOT NULL,
  `timp_exp_profesional` varchar(10) COLLATE utf8mb4_spanish_ci NOT NULL,
  `cargo_aspra_actl` varchar(45) COLLATE utf8mb4_spanish_ci NOT NULL,
  `tiemp_en_cargo` varchar(10) COLLATE utf8mb4_spanish_ci NOT NULL,
  `tipo_cargo` varchar(90) COLLATE utf8mb4_spanish_ci NOT NULL,
  `centro_al_que_pertene` varchar(50) COLLATE utf8mb4_spanish_ci NOT NULL,
  `dependencia` varchar(50) COLLATE utf8mb4_spanish_ci NOT NULL,
  `jornada_de_trabajo` varchar(150) COLLATE utf8mb4_spanish_ci NOT NULL,
  `extra` varchar(5) COLLATE utf8mb4_spanish_ci NOT NULL,
  `manip_alimtos` varchar(5) COLLATE utf8mb4_spanish_ci NOT NULL,
  `traba_altras` varchar(45) COLLATE utf8mb4_spanish_ci NOT NULL,
  `wisher_id` int(15) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- Volcado de datos para la tabla `registro_usuario`
--

INSERT INTO `registro_usuario` (`id`, `num_documento`, `tipo_doc`, `fecha`, `genero`, `primer_nombre`, `segundo_nombre`, `primer_apellido`, `segundo_apellido`, `fch_nacimiento`, `edad`, `lugar_nacimiento`, `estado_civil`, `direccion_domicilio`, `barrio`, `tel_domicilio`, `cel_domicilio`, `eps`, `arl`, `fondo_pensiones`, `caja_compensacion`, `nom_cntcto_fmliar`, `parentesco`, `tel_fmliar`, `cel_fmliar`, `nombre_empresa`, `telefono`, `oficio_habitual`, `deporte_practicar`, `evaluador`, `nivel_academico_actual`, `estudiando`, `profesion`, `timp_exp_profesional`, `cargo_aspra_actl`, `tiemp_en_cargo`, `tipo_cargo`, `centro_al_que_pertene`, `dependencia`, `jornada_de_trabajo`, `extra`, `manip_alimtos`, `traba_altras`, `wisher_id`) VALUES
(23, '0', 'rrrrrrrrrrrrrrrrrr', '0000-00-00 00:00:00', 'qqqqqqqq', 'qqqqqqqqq', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', 10),
(24, '0', 'ttttttttttttttt', '0000-00-00 00:00:00', 'qqqqqqqq', 'qqqqqqqqq', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', 10),
(25, '0', 'wwww', '0000-00-00 00:00:00', 'qqqqqqqq', 'qqqqqqqqq', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', 10),
(28, '0', 'wwwwwwwwwwwwwwwwwwwwwwwwwwwww', '0000-00-00 00:00:00', 'qqqqqqqq', 'qqqqqqqqq', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', 10),
(29, '2011', '111111111111111', '0000-00-00 00:00:00', 'qqqqqqqq', 'qqqqqqqqq', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', 10),
(30, '2015', 'cc', '0000-00-00 00:00:00', 'qqqqqqqq', 'qqqqqqqqq', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', 10),
(31, '2015', 'ti', '0000-00-00 00:00:00', 'qqqqqqqq', 'qqqqqqqqq', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', 10),
(32, '2015', 'ti', '0000-00-00 00:00:00', 'qqqqqqqq', 'qqqqqqqqq', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', 10),
(33, '2014', 'nuip', '0000-00-00 00:00:00', 'qqqqqqqq', 'qqqqqqqqq', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', 10),
(34, '2014', '', '0000-00-00 00:00:00', 'qqqqqqqq', 'qqqqqqqqq', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', 10),
(35, '2014', '', '0000-00-00 00:00:00', 'qqqqqqqq', 'qqqqqqqqq', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', 10),
(36, '2014', '', '0000-00-00 00:00:00', 'qqqqqqqq', 'qqqqqqqqq', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', 10),
(37, '2014', '', '0000-00-00 00:00:00', 'qqqqqqqq', 'qqqqqqqqq', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', 10),
(38, '2014', '', '1000-00-00 00:00:00', 'qqqqqqqq', 'qqqqqqqqq', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', 10),
(39, '2015', '', '2020-00-00 00:00:00', 'qqqqqqqq', 'qqqqqqqqq', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', 10),
(40, '2013', 'ti', '2030-00-00 00:00:00', 'qqqqqqqq', 'qqqqqqqqq', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', 10),
(41, '2015', 'nuip', '0000-00-00 00:00:00', 'qqqqqqqq', 'qqqqqqqqq', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', 10),
(42, '2015', 'nuip', '0000-00-00 00:00:00', 'm', 'm', 'm', 'm', 'm', '2015-08-11', '45', 'Ã±', 'Ã±', 'Ã±', 'Ã±', 'Ã±', 'Ã±', 'Ã±', 'Ã±', 'Ã±', 'Ã±', 'Ã±', 'Ã±', 'Ã±', 'Ã±', 'Ã±', 'Ã±', 'Ã±', 'Ã±', 'Ã±', 0, '', '', '', '', '', '', '', '', '', '', '', '', 10),
(43, '2015', 'ti', '1111-11-11 11:11:11', 'hombre', 'Alexander', 'quen', 'pala', 'riva', '2015-08-26', '56', 'cali', 'casado', 'carrera 30000', 'diamante', '3967247', '3105355799', 'comevA', 'sura', 'porvenir', 'no tengo', 'esperanza', 'madre', '9999999', '666666', 'cali Colombia', '2222222', 'independiente', 'futblo', 'instructor', 0, '', '', '', '', '', '', '', '', '', '', '', '', 10),
(44, '2011', 'cc', '0000-00-00 00:00:00', 'hhhhhh', 'hhhhhhhh', 'hhhhhhhhh', 'hhhhhhhhhhh', 'hhhhhhhhhhhhhhh', '2015-08-27', '99', 'hhhhhhhhhhhh', 'hhhhhhhhh', 'hhhhhhhhhh', 'hhhhh', 'hhhhhhhhh', 'hhhhhhhh', 'hhhhhhh', 'hhhhhhhhh', 'hhhhhhhhhhhh', 'hhhhhhhhh', 'hhhhh', 'hhhhhhhhhhhhhhhh', 'hhhhhhhhhhhh', 'hhhhhhhhhhh', 'hhhhhhhhhhhh', 'hhhhhhhhhh', 'hhhhhhhhh', 'hhhhhhhh', 'hhhhhhhhhhhhh', 0, '', '', '', '', '', '', '', '', '', '', '', '', 10),
(45, '9191', 'cc', '0000-00-00 00:00:00', 'MAS', 'PEDRO', 'jjjjjjjjjjjjj', 'jjjjjjjjjjjjjjj', 'jjjjjjjjjjjjjjjjjjjjjj', '2015-08-22', '88', 'jjjjjjjjjjjjj', 'jjjjjjjjjjjj', 'jjjjjjjjjjjj', 'jjjjjjjjjjj', 'jjjjjjjjjjjjjj', 'jjjjjjjjjjjjjj', 'jjjjjjjjjjjjjjjj', 'jjjjjjjjjjjjjjjjjj', 'jjjjjjjjjjjjjjjjjjjjj', 'jjjjjjjjjjjjjjjjjjjjj', 'jjjjjjjjjjjjjjjjjjj', 'jjjjjjjjjjjjjjjjjjjjjjjj', 'jjjjjjjjjjjjjjjjjjjjjjjjjj', 'jjjjjjjjjjjjjjjjjjjjjjj', 'jjjjjjjjjjjjjjjjjjjj', 'jjjjjjjjjjjjjjjjjjj', 'jjjjjjjjjjjjjjjjjjjjjj', 'jjjjjjjjjjjjjjjj', 'LIDER1', 111, '', '', '', '', '', '', '', '', '', '', '', '', 10),
(46, '2015', 'ce', '0000-00-00 00:00:00', 't', 't', 't', 't', 't', '2015-08-01', '100', 't', 't', 't', 't', 't', 't', 't', 't', 't', 't', 't', 't', 't', 't', 't', 't', 't', 't', 'lider3', 333, '', '', '', '', '', '', '', '', '', '', '', '', 13),
(47, '2015', 'cc', '0000-00-00 00:00:00', 'o', 'o', 'o', 'o', 'o', '2015-08-07', '89', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'o', 'lider3', 333, '', '', '', '', '', '', '', '', '', '', '', '', 13),
(48, '2015', 'cc', '0000-00-00 00:00:00', 'p', 'p', 'p', 'p', 'p', '2015-08-26', '78', 'p', 'p', 'p', 'p', 'p', 'p', 'p', 'p', 'p', 'p', 'p', 'p', 'p', 'p', 'p', 'p', 'p', 'p', 'lider3', 333, '', '', '', '', '', '', '', '', '', '', '', '', 13),
(49, '2015', 'cc', '0000-00-00 00:00:00', 'l', 'l', 'l', 'l', 'l', '2015-08-17', '765', 'l', 'l', 'l', 'l', 'l', 'l', 'l', 'l', 'l', 'l', 'l', 'l', 'l', 'l', 'l', 'l', 'l', 'l', 'lider3', 333, '', '', '', '', '', '', '', '', '', '', '', '', 13),
(50, '2014', 'ti', '0000-00-00 00:00:00', 'd', 'd', 'd', 'd', 'd', '2015-08-24', 'd', 'd', 'd', 'd', 'd', 'd', 'd', 'd', 'd', 'd', 'd', 'd', 'd', 'd', 'd', 'd', 'd', 'd', 'd', 'lider3', 333, '', '', '', '', '', '', '', '', '', '', '', '', 13),
(51, '2015', 'cc', '0000-00-00 00:00:00', 's', 's', 's', 's', 's', '2015-08-16', '76', 's', 's', 's', 's', 's', 's', 's', 's', 's', 's', 's', 's', 's', 's', 's', 's', 's', 's', 'lider3', 333, '', '', '', '', '', '', '', '', '', '', '', '', 13),
(52, '2015', 'cc', '0000-00-00 00:00:00', '000', '00', '00', '00', '00', '2015-08-30', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', 'lider3', 333, '', '', '', '', '', '', '', '', '', '', '', '', 13),
(53, '2015', 'cc', '0000-00-00 00:00:00', 'b', 'b', 'b', 'b', 'b', '2015-08-10', 'b', 'b', 'b', 'b', 'b', 'b', 'b', 'b', 'b', 'b', 'b', 'b', 'b', 'b', 'b', 'b', 'b', 'b', 'b', 'lider2', 222, '', '', '', '', '', '', '', '', '', '', '', '', 14),
(60, '1112462239', 'cc', '2019-01-22 00:00:00', 'jjjjjjjjjjjj', 'BLANCA', 'Maria', 'Potes', 'De Palacios', '2019-01-21', '32', 'Cali', 'Casada', 'Carrera 41 # 25-32', 'San Carlos', '4365231', '3235315307', 'Comeva', '', '', '', '', '', '', '', '', '', '', '', 'LIDER1', 111, '', '', '', '', '', '', '', '', '', '', '', '', 10),
(61, '456789', 'cc', '2019-01-22 00:00:00', 'jjjjjjjjjjjj', 'NURY', 'Valdes', 'AlimaÃ±a', 'Castro', '2019-01-21', '70', 'USA', 'soltero', 'Vavavav', 'SASASAS', 'vavavavavaSAS', 'SASASAS', 'ASSAS', '', '', '', '', '', '', '', '', '', '', '', 'LIDER1', 111, '', '', '', '', '', '', '', '', '', '', '', '', 10),
(64, '67', 'cc', '2019-01-23 00:00:00', '18', 'Carlos', 'Leon', 'Calvache', 'Sanchez', '2019-01-23', '', 'Cali', '13', 'Carrera 41 # 27-32', 'San Carlos', '4365231', '', '', '', '', '', '', '', '', '', '', '', '', '', 'LIDER1', 0, '', '', '', '', '', '', '', '', '', '', '', '', 10),
(65, '89', 'cc', '2019-01-23 00:00:00', 'jjjjjjjjjjjj', 'JUAN', 'Maria', 'AlimaÃ±a', 'De Palacios', '2019-01-16', '', 'Cali', '13', 'Carrera 41 # 25-32', 'San Carlos', '4365231', '', '', '', '', '', '', '', '', '', '', '', '', '', 'LIDER1', 111, '', '', '', '', '', '', '', '', '', '', '', '', 10);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `registro_administrador`
--
ALTER TABLE `registro_administrador`
 ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `registro_usuario`
--
ALTER TABLE `registro_usuario`
 ADD PRIMARY KEY (`id`), ADD KEY `fk_wish_wisher` (`wisher_id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `registro_administrador`
--
ALTER TABLE `registro_administrador`
MODIFY `id` int(15) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT de la tabla `registro_usuario`
--
ALTER TABLE `registro_usuario`
MODIFY `id` int(15) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=66;
--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `registro_usuario`
--
ALTER TABLE `registro_usuario`
ADD CONSTRAINT `fk_wish_wisher` FOREIGN KEY (`wisher_id`) REFERENCES `registro_administrador` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
